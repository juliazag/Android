package com.example.contacts.tasks;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.appcompat.app.AppCompatActivity;

import com.example.contacts.R;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TaskListContent extends AppCompatActivity {

    public static final List<Task> ITEMS = new ArrayList<Task>();
    public static final Map<String, Task> ITEM_MAP = new HashMap<String, Task>();

    private static final int COUNT = 1;

    public static int [] images = new int[]{R.drawable.avatar_1, R.drawable.avatar_2, R.drawable.avatar_3, R.drawable.avatar_4,
            R.drawable.avatar_5, R.drawable.avatar_6, R.drawable.avatar_7,
            R.drawable.avatar_8, R.drawable.avatar_9, R.drawable.avatar_10,
            R.drawable.avatar_11, R.drawable.avatar_12, R.drawable.avatar_13,
            R.drawable.avatar_14, R.drawable.avatar_15, R.drawable.avatar_16};

    static {
        // Add some sample items.
        for (int i = 1; i <= COUNT; i++) {
            addItem(createDummyItem(i));
        }
    }

    public static void addItem(Task item) {
        ITEMS.add(item);
        ITEM_MAP.put(item.name, item);
    }

    private static Task createDummyItem(int position) {
        return new Task("Julia", "Zagrodnik", "20.03.1998", "698678956", TaskListContent.images[10]);
    }

    public static void removeItem(int position) {
        String itemName = ITEMS.get(position).name;
        ITEMS.remove(position);
        ITEM_MAP.remove(itemName);
    }

    public static class Task implements Parcelable {
        public final String name;
        public final String surname;
        public final String birth;
        public final String phone;
        public final int image;

        public Task(String name, String surname, String birth, String phone, int image) {
            this.name = name;
            this.surname = surname;
            this.birth = birth;
            this.phone = phone;
            this.image = image;
        }

        @Override
        public String toString() {
            String content = null;
            return content;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {

        }
    }
}
