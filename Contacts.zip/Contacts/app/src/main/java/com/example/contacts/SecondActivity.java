package com.example.contacts;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.contacts.tasks.TaskListContent;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
    }

    public void addClick(View view) {
        EditText taskName = findViewById(R.id.name);
        EditText taskSurname = findViewById(R.id.surname);
        EditText taskBirthday = findViewById(R.id.birthday);
        EditText taskPhone = findViewById(R.id.phoneNumber);

        String taskN = taskName.getText().toString();
        String taskS = taskSurname.getText().toString();
        String taskB = taskBirthday.getText().toString();
        String taskP = taskPhone.getText().toString();

        Context context = getApplicationContext();

        int imageId = (int) (Math.random() * TaskListContent.images.length);

        if (taskN.isEmpty() || taskS.isEmpty() || taskB.isEmpty() || taskP.isEmpty()){
            Toast.makeText(context, "Fill all inputs!", Toast.LENGTH_SHORT).show();
        }
        else if(taskB.length()<8 || taskP.length()<9){
            Toast.makeText(context, "Wrong birthday day or phone number!", Toast.LENGTH_SHORT).show();
        }
        else if(letter(taskN) == false || letter(taskS) == false){
            Toast.makeText(context, "Should use only letters name or surname!", Toast.LENGTH_SHORT).show();
        }
        else if(number(taskB) == false || number(taskP) == false){
            Toast.makeText(context, "Should use only numbers birthday day or phone number!", Toast.LENGTH_SHORT).show();
        }
        else{
            TaskListContent.addItem(new TaskListContent.Task(taskN, taskS, taskB, taskP, TaskListContent.images[imageId]));
            Toast.makeText(context, "Added " + taskN+" to contacts ;)", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        }
    }

    public boolean letter(String word){
        for(int i = 0; i < word.length(); i++){
            if(Character.isDigit(word.charAt(i))) return false;
        }
        return true;
    }

    public boolean number(String word){
        for(int i = 0; i < word.length(); i++){
            if(!Character.isDigit(word.charAt(i))) return false;
        }
        return true;
    }
}
