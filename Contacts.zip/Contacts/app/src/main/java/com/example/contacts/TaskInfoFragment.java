package com.example.contacts;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.contacts.tasks.TaskListContent;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TaskInfoFragment extends Fragment {

    public TaskInfoFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_task_info, container, false);
    }

    @SuppressLint("SetTextI18n")
    public void displayTask(TaskListContent.Task task){
        FragmentActivity activity = getActivity();

        TextView imie_nazwisko = activity.findViewById(R.id.imie_nazwisko_f);
        TextView numer = activity.findViewById(R.id.numer_f);
        TextView data = activity.findViewById(R.id.data_f);
        ImageView zdjecie = activity.findViewById(R.id.zdjecie_f);

        imie_nazwisko.setText(task.name + task.surname);
        numer.setText("Phone number: " + task.phone);

        String date = task.birth;
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/mm/yyyy");
        try{
            Date d = dateFormat.parse(date);
            data.setText("Birthday date: " + d);
        }catch (Exception e){
            e.printStackTrace();
        }

        zdjecie.setImageResource(task.image);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);
        Intent intent = getActivity().getIntent();
        if(intent != null){
            TaskListContent.Task receiverTask = intent.getParcelableExtra(MainActivity.taskExtra);
            if(receiverTask != null){
                displayTask(receiverTask);
            }
        }
    }
}
